
function skraHugtakLoad() {
  document.getElementById('hugtak-enska').setAttribute('value', window.opener.document.getElementById('hugtak-enska').value);
  document.getElementById('hugtak-islenska').setAttribute('value', window.opener.document.getElementById('hugtak-islenska').value);
  document.getElementById('hugtak-daemi-enskt').setAttribute('value', window.opener.document.getElementById('hugtak-daemi-enskt').value);
  document.getElementById('hugtak-daemi-islenskt').setAttribute('value', window.opener.document.getElementById('hugtak-daemi-islenskt').value);
  document.getElementById('hugtak-rit').setAttribute('value', window.opener.document.getElementById('hugtak-rit').value);
  document.getElementById('hugtak-skjal').setAttribute('value', window.opener.document.getElementById('hugtak-skjal').value);
  var doctree = window.opener.document.getElementById("skjol-tree");
  document.getElementById('hugtak-rit').setAttribute('value', 
    doctree.view.getCellText(doctree.currentIndex,"skjol-rit") + " " +
    doctree.view.getCellText(doctree.currentIndex,"skjol-flokkun") + " " +
    doctree.view.getCellText(doctree.currentIndex,"skjol-dags") + " " +
    doctree.view.getCellText(doctree.currentIndex,"skjol-bls")
  );
}

//skr� hugtaki� � gagnagrunn
function skraHugtak() {
  var req = new XMLHttpRequest(); // Request
  var res = null; // Response
  var params = encodeURI("enska=" + document.getElementById("hugtak-enska").value +
               "&islenska=" + document.getElementById("hugtak-islenska").value +
               "&daemienska=" + document.getElementById("hugtak-daemi-enskt").value +
               "&daemiislenska=" + document.getElementById("hugtak-daemi-islenskt").value +
               "&rit=" + document.getElementById("hugtak-rit").value +
               "&skjal=" + document.getElementById("hugtak-skjal").value +
               "&samheiti=" + document.getElementById("hugtak-samheiti").value +
               "&svid=" + document.getElementById("hugtak-svid").value +
               "&uppruni=" + document.getElementById("hugtak-uppruni").value +
               "&heimild=" + document.getElementById("hugtak-heimild").value +
               "&athugasemd=" + document.getElementById("hugtak-athugasemd").value +
               "&adalord=" + document.getElementById("hugtak-adalord").value +
               "&ordflokkur=" + document.getElementById("hugtak-ordflokkur").value +
               "&kyn=" + document.getElementById("hugtak-kyn").value +
               "&onnurmalfraedi=" + document.getElementById("hugtak-onnurmalfraedi").value +
               "&skammstofun=" + document.getElementById("hugtak-skammstofun").value +
               "&skilgreining=" + document.getElementById("hugtak-skilgreining").value +
               "&nafnordtaka=" + document.getElementById("hugtak-nafn-ordtaka").value);

  req.open("POST", "http://hugtakasafn.utn.stjr.is/hugtakagripill/xul-skra-hugtak.tcl");
//  req.setRequestHeader("Content-Type","multipart/form-data"); 
//  req.setRequestHeader("Content-Encoding","ISO-8859-1"); 
  req.send(params);
  
  window.close();
}
